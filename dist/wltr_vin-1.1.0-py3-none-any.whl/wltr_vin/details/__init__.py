from .avtovaz import AvtoVazDetails
from .nissan import NissanDetails
from .opel import OpelDetails
from .renault import RenaultDetails
